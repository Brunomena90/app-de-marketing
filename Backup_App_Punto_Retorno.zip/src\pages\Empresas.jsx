import React, { useState, useEffect } from 'react';
import {
    Plus, Building2, Search, Trash2, Edit2, Layers,
    ChevronDown, ChevronUp, Check, Power, PowerOff,
    LayoutGrid, Megaphone, TrendingUp, Sparkles, Lock, Unlock, Palette, Wallet
} from 'lucide-react';

/* ─── Catálogo de módulos disponibles ─────────────────────── */
const ALL_MODULES = [
    { id: 'marketing',   label: 'Marketing',        icon: <Megaphone size={15} />,   color: 'text-blue-600 bg-blue-50 border-blue-200' },
    { id: 'ventas',      label: 'Ventas',            icon: <TrendingUp size={15} />,  color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
    { id: 'workflow-ai', label: 'WorkFlow AI',       icon: <Sparkles size={15} />,   color: 'text-fuchsia-600 bg-fuchsia-50 border-fuchsia-200' },
    { id: 'branding',    label: 'Marca & Estrategia',icon: <Palette size={15} />,    color: 'text-pink-600 bg-pink-50 border-pink-200' },
    { id: 'finanzas',    label: 'Gestión Financiera',icon: <Wallet size={15} />,     color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
    { id: 'empresas',    label: 'Gestión Empresas',  icon: <Building2 size={15} />,  color: 'text-violet-600 bg-violet-50 border-violet-200' },
];
import {
    deleteDoc, doc, where, updateDoc,
    collection, query, orderBy, onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { toast } from 'sonner';
import { useAuth } from '../context/AuthContext';
import NewEmpresaModal from '../components/NewEmpresaModal';
import NewAreaModal from '../components/NewAreaModal';
import ConfirmModal from '../components/ConfirmModal';

/* ─────────────────────────────────────────────────────────── */
/*  Helpers                                                    */
/* ─────────────────────────────────────────────────────────── */
const getInitials = (name) => {
    if (!name) return '?';
    return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
};

const getBgColor = (name) => {
    if (!name) return 'bg-gray-500';
    const colors = [
        'bg-blue-500', 'bg-indigo-500', 'bg-purple-500', 'bg-pink-500',
        'bg-rose-500', 'bg-orange-500', 'bg-amber-500', 'bg-teal-500',
        'bg-cyan-500', 'bg-emerald-500',
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash += name.charCodeAt(i);
    return colors[hash % colors.length];
};

/* ─────────────────────────────────────────────────────────── */
/*  Componente principal                                       */
/* ─────────────────────────────────────────────────────────── */
const Empresas = () => {
    const { activeEmpresa, isSuper1, isSuper2, isAdmin } = useAuth();
    const [empresas, setEmpresas] = useState([]);
    const [areas, setAreas] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    /* Paneles expandibles — 'areas' | 'modulos' | null por empresa */
    const [expandedPanel, setExpandedPanel] = useState({ id: null, panel: null });

    /* Modal empresa */
    const [empresaModal, setEmpresaModal] = useState({ open: false, item: null });

    /* Modal área */
    const [areaModal, setAreaModal] = useState({ open: false, item: null, empresaId: null, empresaName: null });

    /* Modal confirmación */
    const [confirmModal, setConfirmModal] = useState({
        open: false, type: '', id: null, name: '', loading: false
    });

    /* Actualizar módulos de una empresa */
    const handleToggleModule = async (empresa, moduleId) => {
        const current = Array.isArray(empresa.accessibleModules) ? empresa.accessibleModules : [];
        const updated = current.includes(moduleId)
            ? current.filter(m => m !== moduleId)
            : [...current, moduleId];
        try {
            await updateDoc(doc(db, 'empresas', empresa.id), { accessibleModules: updated });
            toast.success(`Módulo ${updated.includes(moduleId) ? 'habilitado' : 'deshabilitado'}`);
        } catch {
            toast.error('Error al actualizar módulos');
        }
    };

    const togglePanel = (empresaId, panel) => {
        setExpandedPanel(prev =>
            prev.id === empresaId && prev.panel === panel
                ? { id: null, panel: null }
                : { id: empresaId, panel }
        );
    };

    /* ── Cargar datos ── */
    useEffect(() => {
        const unsubE = onSnapshot(
            query(collection(db, 'empresas'), orderBy('name')),
            snap => {
                setEmpresas(snap.docs.map(d => ({ id: d.id, ...d.data() })));
                setLoading(false);
            }
        );
        const unsubA = onSnapshot(
            query(collection(db, 'areas'), orderBy('name')),
            snap => setAreas(snap.docs.map(d => ({ id: d.id, ...d.data() })))
        );
        return () => { unsubE(); unsubA(); };
    }, []);

    const getAreasDeEmpresa = (empresaId) =>
        areas.filter(a => a.empresaId === empresaId);

    /* ── Eliminar ── */
    const handleConfirmDelete = async () => {
        setConfirmModal(p => ({ ...p, loading: true }));
        try {
            const col = confirmModal.type === 'empresa' ? 'empresas' : 'areas';
            await deleteDoc(doc(db, col, confirmModal.id));
            toast.success(`${confirmModal.type === 'empresa' ? 'Empresa' : 'Área'} eliminada`);
            setConfirmModal({ open: false, type: '', id: null, name: '', loading: false });
        } catch {
            toast.error('Error al eliminar');
            setConfirmModal(p => ({ ...p, loading: false }));
        }
    };

    const handleToggleStatus = async (e, empresa) => {
        e.stopPropagation();
        if (!isSuper1 && !isSuper2) {
            toast.error('Privilegios insuficientes para cambiar el estado de la empresa');
            return;
        }
        try {
            const newStatus = empresa.status === 'off' ? 'on' : 'off';
            await updateDoc(doc(db, 'empresas', empresa.id), {
                status: newStatus
            });
            toast.success(`Empresa ${newStatus === 'on' ? 'activada' : 'desactivada'}`);
        } catch {
            toast.error('Error al cambiar estado');
        }
    };

    const filteredEmpresas = empresas.filter(e => {
        const matchesSearch = e.name.toLowerCase().includes(search.toLowerCase());
        const matchesActive = activeEmpresa === 'Todas' ? true : e.name === activeEmpresa;
        return matchesSearch && matchesActive;
    });

    const isCanManage = isAdmin || isSuper1 || isSuper2;

    return (
        <div className="space-y-6">

            {/* ── HEADER ── */}
            <div className="bg-white p-4 md:p-5 rounded-xl shadow-sm border border-gray-100">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                        <h1 className="text-xl md:text-2xl font-bold text-gray-800">Gestión de Empresas</h1>
                        <p className="text-sm text-gray-500">Administra empresas y sus áreas operativas.</p>
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                        <div className="relative flex-1 sm:w-56">
                            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
                            <input
                                type="text"
                                placeholder="Buscar empresa..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                                className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                            />
                        </div>
                        <button
                            onClick={() => setEmpresaModal({ open: true, item: null })}
                            className="bg-gray-900 hover:bg-black text-white font-bold py-2 px-4 rounded-lg shadow-md flex items-center justify-center gap-1.5 text-sm transition-transform active:scale-95 whitespace-nowrap"
                        >
                            <Plus size={16} /> <span className="hidden sm:inline">Nueva Empresa</span><span className="sm:hidden">Nueva</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* ── LISTA DE EMPRESAS ── */}
            {loading ? (
                <div className="space-y-4">
                    {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="bg-white rounded-xl border border-gray-100 p-6 animate-pulse h-20" />
                    ))}
                </div>
            ) : filteredEmpresas.length === 0 ? (
                <div className="py-24 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 mb-4">
                        <Building2 size={32} className="text-gray-300" />
                    </div>
                    <p className="text-gray-500 font-medium text-lg">No se encontraron empresas</p>
                    <p className="text-gray-400 text-sm mt-1">
                        {search ? `Sin resultados para "${search}"` : 'Crea la primera empresa con el botón de arriba.'}
                    </p>
                </div>
            ) : (
                <div className="space-y-4">
                    {filteredEmpresas.map(empresa => {
                        const areasEmpresa = getAreasDeEmpresa(empresa.id);
                        const isAreasOpen   = expandedPanel.id === empresa.id && expandedPanel.panel === 'areas';
                        const isModulosOpen = expandedPanel.id === empresa.id && expandedPanel.panel === 'modulos';
                        const enabledMods   = Array.isArray(empresa.accessibleModules) ? empresa.accessibleModules : [];

                        return (
                            <div key={empresa.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden transition-all">

                                {/* ── Cabecera de empresa ── */}
                                <div className="p-4 md:p-5">
                                    <div className="flex items-start gap-3">
                                        {/* Avatar */}
                                        <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-white font-bold text-base md:text-lg shrink-0 ${getBgColor(empresa.name)}`}>
                                            {getInitials(empresa.name)}
                                        </div>

                                        {/* Info + Acciones */}
                                        <div className="flex-1 min-w-0">
                                            {/* Name row */}
                                            <div className="flex items-center gap-1.5 flex-wrap">
                                                {isCanManage && (
                                                    <button
                                                        onClick={(e) => handleToggleStatus(e, empresa)}
                                                        className={`p-1 rounded-lg transition-all active:scale-90 shrink-0 ${empresa.status === 'off' ? 'text-red-500 bg-red-50' : 'text-emerald-500 bg-emerald-50'}`}
                                                        title={empresa.status === 'off' ? 'Encender empresa' : 'Apagar empresa'}
                                                    >
                                                        {empresa.status === 'off' ? <PowerOff size={15} /> : <Power size={15} />}
                                                    </button>
                                                )}
                                                <h2 className="font-bold text-gray-800 text-base md:text-lg truncate">{empresa.name}</h2>
                                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider shrink-0 ${empresa.status === 'off' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
                                                    {empresa.status === 'off' ? 'Apagado' : 'Encendido'}
                                                </span>
                                            </div>

                                            {/* Stats */}
                                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                                                <span className="text-[11px] text-gray-400 hidden sm:block">
                                                    {empresa.createdAt ? `Creada el ${new Date(empresa.createdAt).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}` : 'Empresa registrada'}
                                                </span>
                                                <span className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                                                    <Layers size={10} />
                                                    {areasEmpresa.length} área{areasEmpresa.length !== 1 ? 's' : ''}
                                                </span>
                                                <span className="flex items-center gap-1 text-[11px] font-semibold text-violet-600 bg-violet-50 px-2 py-0.5 rounded-full">
                                                    <LayoutGrid size={10} />
                                                    {enabledMods.length} módulo{enabledMods.length !== 1 ? 's' : ''}
                                                </span>
                                            </div>

                                            {/* Action buttons — wrap naturally on mobile */}
                                            <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                                                <button onClick={() => setEmpresaModal({ open: true, item: empresa })} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors" title="Editar empresa">
                                                    <Edit2 size={15} />
                                                </button>
                                                <button onClick={() => setConfirmModal({ open: true, type: 'empresa', id: empresa.id, name: empresa.name, loading: false })} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors" title="Eliminar empresa">
                                                    <Trash2 size={15} />
                                                </button>

                                                {isCanManage && (
                                                    <button
                                                        onClick={() => togglePanel(empresa.id, 'modulos')}
                                                        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                                                            isModulosOpen ? 'bg-violet-600 text-white' : 'bg-violet-50 text-violet-700 border border-violet-200 hover:bg-violet-100'
                                                        }`}
                                                    >
                                                        <LayoutGrid size={12} /> Módulos
                                                        {isModulosOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                                    </button>
                                                )}

                                                <button
                                                    onClick={() => togglePanel(empresa.id, 'areas')}
                                                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                                                        isAreasOpen ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                                    }`}
                                                >
                                                    <Layers size={12} /> Áreas
                                                    {isAreasOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* ── Panel de MÓDULOS ── */}
                                {isModulosOpen && (
                                    <div className="border-t border-gray-100 bg-violet-50/40 px-4 py-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <h3 className="text-xs font-bold text-violet-700 uppercase tracking-wider flex items-center gap-1.5">
                                                <LayoutGrid size={12} /> Módulos — <span className="truncate max-w-[120px] sm:max-w-none">{empresa.name}</span>
                                            </h3>
                                            <span className="text-[10px] text-violet-400 font-medium">
                                                {enabledMods.length}/{ALL_MODULES.length} habilitados
                                            </span>
                                        </div>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                            {ALL_MODULES.map(mod => {
                                                const isEnabled = enabledMods.includes(mod.id);
                                                return (
                                                    <button
                                                        key={mod.id}
                                                        onClick={() => handleToggleModule(empresa, mod.id)}
                                                        className={`flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all text-left group ${
                                                            isEnabled
                                                                ? 'bg-white border-violet-300 shadow-sm'
                                                                : 'bg-white/60 border-dashed border-gray-200 hover:border-gray-300'
                                                        }`}
                                                    >
                                                        {/* Icono del módulo */}
                                                        <div className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 transition-all ${
                                                            isEnabled ? mod.color : 'bg-gray-50 border-gray-200 text-gray-300'
                                                        }`}>
                                                            {mod.icon}
                                                        </div>

                                                        {/* Label */}
                                                        <div className="flex-1 min-w-0">
                                                            <p className={`text-sm font-bold truncate ${
                                                                isEnabled ? 'text-gray-800' : 'text-gray-400'
                                                            }`}>{mod.label}</p>
                                                            <p className="text-[10px] font-medium mt-0.5">
                                                                {isEnabled
                                                                    ? <span className="text-violet-500 flex items-center gap-1"><Unlock size={9} /> Acceso habilitado</span>
                                                                    : <span className="text-gray-400 flex items-center gap-1"><Lock size={9} /> Sin acceso</span>
                                                                }
                                                            </p>
                                                        </div>

                                                        {/* Toggle visual */}
                                                        <div className={`w-10 h-6 rounded-full flex items-center transition-all shrink-0 px-0.5 ${
                                                            isEnabled ? 'bg-violet-500 justify-end' : 'bg-gray-200 justify-start'
                                                        }`}>
                                                            <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
                                                        </div>
                                                    </button>
                                                );
                                            })}
                                        </div>
                                        <p className="text-[10px] text-violet-400 mt-3 text-center">
                                            Los cambios se aplican en tiempo real. Los usuarios de esta empresa solo verán los módulos habilitados.
                                        </p>
                                    </div>
                                )}

                                {/* ── Panel de ÁREAS ── */}
                                {isAreasOpen && (
                                    <div className="border-t border-gray-100 bg-gray-50/60 px-5 py-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                                                <Layers size={12} /> Áreas de {empresa.name}
                                            </h3>
                                            <button
                                                onClick={() => setAreaModal({ open: true, item: null, empresaId: empresa.id, empresaName: empresa.name })}
                                                className="flex items-center gap-1.5 bg-white border border-gray-200 hover:border-blue-400 hover:text-blue-600 text-gray-600 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                                            >
                                                <Plus size={13} /> Nueva Área
                                            </button>
                                        </div>
                                        {areasEmpresa.length === 0 ? (
                                            <div className="py-8 text-center">
                                                <Layers size={24} className="text-gray-300 mx-auto mb-2" />
                                                <p className="text-xs text-gray-400">Esta empresa no tiene áreas aún.</p>
                                            </div>
                                        ) : (
                                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                                                {areasEmpresa.map(area => (
                                                    <div key={area.id} className="bg-white rounded-lg border border-gray-200 px-4 py-3 flex items-center gap-3 group hover:shadow-sm transition-all">
                                                        <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                                                            <Layers size={14} className="text-blue-500" />
                                                        </div>
                                                        <span className="flex-1 text-sm font-semibold text-gray-700 uppercase truncate">{area.name}</span>
                                                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <button onClick={() => setAreaModal({ open: true, item: area, empresaId: empresa.id, empresaName: empresa.name })} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"><Edit2 size={13} /></button>
                                                            <button onClick={() => setConfirmModal({ open: true, type: 'area', id: area.id, name: area.name, loading: false })} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"><Trash2 size={13} /></button>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}

            {/* ── MODALES ── */}
            <NewEmpresaModal
                isOpen={empresaModal.open}
                onClose={() => setEmpresaModal({ open: false, item: null })}
                empresaToEdit={empresaModal.item}
            />

            <NewAreaModal
                isOpen={areaModal.open}
                onClose={() => setAreaModal({ open: false, item: null, empresaId: null, empresaName: null })}
                areaToEdit={areaModal.item}
                defaultEmpresaId={areaModal.empresaId}
                defaultEmpresaName={areaModal.empresaName}
            />

            <ConfirmModal
                isOpen={confirmModal.open}
                onClose={() => setConfirmModal({ open: false, type: '', id: null, name: '', loading: false })}
                onConfirm={handleConfirmDelete}
                title={`¿Eliminar ${confirmModal.type === 'empresa' ? 'Empresa' : 'Área'}?`}
                message={
                    confirmModal.type === 'empresa'
                        ? `¿Seguro que deseas eliminar "${confirmModal.name}"? Sus áreas asociadas no se eliminarán automáticamente.`
                        : `¿Seguro que deseas eliminar el área "${confirmModal.name}"?`
                }
                confirmText="Eliminar"
                loading={confirmModal.loading}
            />
        </div>
    );
};

export default Empresas;
