import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import './index.css'

const rootElement = document.getElementById('root');
rootElement.innerHTML = '<div style="color:red; font-size: 20px;">SCRIPT JS CARGADO. ARRANCANDO REACT...</div>';

ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
        <ErrorBoundary>
            <App />
        </ErrorBoundary>
    </React.StrictMode>,
)
